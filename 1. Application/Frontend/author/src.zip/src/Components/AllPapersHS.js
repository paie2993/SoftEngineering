import React, { useState, useEffect } from "react";
import "./AllPapersHS.css";

export const AllPapersHS = () => {
  return (
    <React.Fragment>
      <span></span>
      <div class="hs-container">
        <div class="hs-title"> TITLE</div>
        <div class="hs-main">
          <div class="hs-main-table">table</div>
          <div class="hs-main-options">options</div>
        </div>
      </div>
    </React.Fragment>
  );
};
