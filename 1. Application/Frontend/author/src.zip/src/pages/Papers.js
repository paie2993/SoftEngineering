import React from "react";
import { Sidebar } from "../Components/Sidebar";
import { AllPapersHS } from "../Components/AllPapersHS";
import "./Papers.css";

export const Papers = () => {
  return (
    <React.Fragment>
      <div class="ap-layout">
        <Sidebar></Sidebar>
        <AllPapersHS></AllPapersHS>
      </div>
    </React.Fragment>
  );
};
